# W5500
W5500 board Keystudio for home automation, simple sketchup for input/output with analog and digital pin

Topic Exemple
"chambre/samuel/climat/"
"chambre/samuel/lumiere/main/status/"
"chambre/samuel/lumiere/main/set/"
![Alt text](W5500.jpg?raw=true "Pinout")


TODO: Add publisher id and enforce security with only id can publish to X topic